
  # 月尘写表器

  This is a code bundle for 月尘写表器. The original project is available at https://www.figma.com/design/BCi64SvwKxwkw6tRJu6ak1/%E6%A1%8C%E6%B8%B8%E7%BC%96%E9%98%9F%E7%AE%A1%E7%90%86%E7%BD%91%E9%A1%B5.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  