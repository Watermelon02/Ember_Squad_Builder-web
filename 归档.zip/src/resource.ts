//图床
export const IMAGE_SRC = { zh: 'https://op-1307392056.cos.ap-guangzhou.myqcloud.com/res/cn', en: `${import.meta.env.BASE_URL}res/en`,jp: `${import.meta.env.BASE_URL}res/jp` }//本地：import.meta.env.BASE_URL
export const LOCAL_IMAGE_SRC = { zh: `${import.meta.env.BASE_URL}res/cn`, en: `${import.meta.env.BASE_URL}res/en`,jp: `${import.meta.env.BASE_URL}res/jp` }//本地：import.meta.env.BASE_URL

export const TAB_IMAGE_SRC = { zh: 'https://op-1307392056.cos.ap-guangzhou.myqcloud.com/res/tab', en: `${import.meta.env.BASE_URL}res/tab`,jp: `${import.meta.env.BASE_URL}res/tab` }//本地：import.meta.env.BASE_URL