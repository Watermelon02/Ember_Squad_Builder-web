//图床
export const IMAGE_SRC ={zh:'https://op-1307392056.cos.ap-guangzhou.myqcloud.com/res/cn',en:`${import.meta.env.BASE_URL}res/cn`}//本地：import.meta.env.BASE_URL
export const LOCAL_IMAGE_SRC = {zh:`${import.meta.env.BASE_URL}res/cn`,en:`${import.meta.env.BASE_URL}res/cn`}//本地：import.meta.env.BASE_URL

